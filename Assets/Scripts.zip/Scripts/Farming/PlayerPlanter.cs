using UnityEngine;

[RequireComponent(typeof(PlayerInventoryHolder))]
[RequireComponent(typeof(ActiveItemController))]
public class PlayerPlanter : MonoBehaviour
{
    [Header("Config")]
    public SeedPlantDataSO plantDB;
    [Tooltip("���߼���õĲ㣨�ѵ���㹴�ϣ�Ϊ 0 ʱ���Զ��� Everything��")]
    public LayerMask raycastLayers = ~0;
    public float maxDistance = 8f;
    public KeyCode plantKey = KeyCode.F;
    public bool useCameraRay = true;
    [Tooltip("�������� PlantableSurface ������")] public bool requirePlantableSurface = true;

    [Header("Marker")]
    public bool showMarker = true;
    public float markerRadius = 0.35f;
    public float markerWidth = 0.02f;
    public float markerYOffset = 0.02f;
    public int markerSegments = 36;
    public Color okColor = new Color(0f, 1f, 0f, 0.95f);
    public Color badColor = new Color(1f, 0f, 0f, 0.95f);

    [Header("Debug")]
    public bool debugLog = false;

    PlayerInventoryHolder _inv;
    ActiveItemController _active;
    float _cooldown;

    LineRenderer _markerLR;
    bool _hasValidPoint;
    Vector3 _cachedPoint, _cachedNormal;

    void Awake()
    {
        _inv = GetComponent<PlayerInventoryHolder>();
        _active = GetComponent<ActiveItemController>();
        if (raycastLayers.value == 0) raycastLayers = ~0; // ���л���ʧʱ����
        CreateMarker();
    }

    void Update()
    {
        if (_cooldown > 0f) _cooldown -= Time.deltaTime;
        UpdateMarker();
        if (Input.GetKeyDown(plantKey)) TryPlant();
    }

    // ---------- ָʾ�� ----------
    void CreateMarker()
    {
        if (!showMarker) return;
        var go = new GameObject("PlantMarker");
        go.layer = LayerMask.NameToLayer("Ignore Raycast"); // ��Ҫ��ס����
        _markerLR = go.AddComponent<LineRenderer>();
        _markerLR.loop = true;
        _markerLR.useWorldSpace = true;
        _markerLR.alignment = LineAlignment.View;
        _markerLR.widthMultiplier = markerWidth;
        _markerLR.numCornerVertices = 4;
        _markerLR.positionCount = markerSegments;

        var sh = Shader.Find("Unlit/Color");
        if (!sh) sh = Shader.Find("Universal Render Pipeline/Unlit");
        if (!sh) sh = Shader.Find("Standard");
        var mat = new Material(sh);
        if (mat.HasProperty("_BaseColor")) mat.SetColor("_BaseColor", okColor);
        if (mat.HasProperty("_Color")) mat.SetColor("_Color", okColor);
        _markerLR.material = mat;
        _markerLR.enabled = false;
    }

    void UpdateMarker()
    {
        if (!showMarker || _markerLR == null) return;

        bool hasHit = Raycast(out var hit);
        PlantableSurface surface = hasHit ? hit.collider.GetComponentInParent<PlantableSurface>() : null;

        // ȡ��ǰ���õ���ֲ��ƷID��ActiveId Ϊ�վʹӱ����ҵ�һ�ֿ��ֵģ�
        string plantId = GetCurrentPlantableId();
        var entry = (!string.IsNullOrEmpty(plantId) && plantDB != null) ? plantDB.GetByPlantItemId(plantId) : null;

        bool canBySurface = (!requirePlantableSurface)
                            || (surface != null && entry != null && entry.cropPrefab
                                && surface.IsItemAllowed(plantId) && surface.IsSlopeOK(hit.normal));

        bool canPlant = hasHit && entry != null && entry.cropPrefab && canBySurface;

        if (debugLog && hasHit)
        {
            if (entry == null) Debug.Log("[Planter] �죺δ�ҵ�������Ŀ��ActiveIdΪ��/plantDBδ����/ID��ƥ�䣩");
            else if (!entry.cropPrefab) Debug.Log("[Planter] �죺��Ŀû�� Crop Prefab");
            else if (requirePlantableSurface && surface == null) Debug.Log("[Planter] �죺���д�û�� PlantableSurface");
            else if (requirePlantableSurface && !surface.IsItemAllowed(plantId)) Debug.Log("[Planter] �죺�õؿ鲻��������Ʒ " + plantId);
            else if (requirePlantableSurface && !surface.IsSlopeOK(hit.normal)) Debug.Log("[Planter] �죺�¶ȳ���");
        }

        if (hasHit)
        {
            Vector3 pos = hit.point;
            Vector3 n = hit.normal;
            if (surface) pos = surface.SnapPosition(pos);
            pos += n * markerYOffset;

            _cachedPoint = pos;
            _cachedNormal = n;
            _hasValidPoint = canPlant;

            DrawCircle(pos, n, markerRadius);

            var c = canPlant ? okColor : badColor;
            if (_markerLR.material.HasProperty("_BaseColor")) _markerLR.material.SetColor("_BaseColor", c);
            if (_markerLR.material.HasProperty("_Color")) _markerLR.material.SetColor("_Color", c);
            _markerLR.enabled = true;
        }
        else
        {
            _hasValidPoint = false;
            _markerLR.enabled = false;
        }
    }

    void DrawCircle(Vector3 center, Vector3 normal, float radius)
    {
        normal = normal.normalized;
        Vector3 tangent = Vector3.Cross(normal, Vector3.up);
        if (tangent.sqrMagnitude < 1e-4f) tangent = Vector3.Cross(normal, Vector3.right);
        tangent.Normalize();
        Vector3 bitangent = Vector3.Cross(normal, tangent);

        for (int i = 0; i < markerSegments; i++)
        {
            float ang = (i / (float)markerSegments) * Mathf.PI * 2f;
            Vector3 dir = Mathf.Cos(ang) * tangent + Mathf.Sin(ang) * bitangent;
            _markerLR.SetPosition(i, center + dir * radius);
        }
    }

    // ---------- ��ֲ ----------
    void TryPlant()
    {
        if (_inv == null || plantDB == null) return;
        if (_cooldown > 0f) return;

        string id = GetCurrentPlantableId();
        if (string.IsNullOrEmpty(id)) return;

        var entry = plantDB.GetByPlantItemId(id);
        if (entry == null || entry.cropPrefab == null) return;

        if (!Raycast(out var hit)) return;
        var surface = hit.collider.GetComponentInParent<PlantableSurface>();
        if (requirePlantableSurface)
        {
            if (surface == null || !surface.IsItemAllowed(id) || !surface.IsSlopeOK(hit.normal)) return;
        }

        Vector3 pos = surface ? surface.SnapPosition(hit.point) : hit.point;
        pos += hit.normal * (surface ? surface.yOffset : 0f);
        Quaternion rot = (surface && surface.alignToNormal)
                       ? Quaternion.FromToRotation(Vector3.up, hit.normal)
                       : Quaternion.identity;

        var cropObj = Object.Instantiate(entry.cropPrefab, pos, rot);
        var crop = cropObj.GetComponent<CropPlant>(); if (!crop) crop = cropObj.AddComponent<CropPlant>();
        crop.Init(entry);

        // ��1 & ���ּ���
        string keepId = id;
        _inv.RemoveItem(id, 1);
        var ui = Object.FindObjectOfType<InventoryUI>(); if (ui) ui.RefreshAll();
        if (StillHasItem(keepId)) { var ac = _active; if (ac != null) { try { ac.SetActive(keepId, true); } catch { } } }

        _cooldown = Mathf.Max(0.05f, entry.plantCooldown);
    }

    string GetCurrentPlantableId()
    {
        // 1) ���� ActiveId
        string id = _active != null ? _active.ActiveId : null;
        if (!string.IsNullOrEmpty(id) && plantDB && plantDB.GetByPlantItemId(id) != null) return id;

        // 2) û�м���ʹӱ������ҵ�һ���� plantDB ����ֵ���Ʒ
        if (_inv?.Inventory?.slots != null && plantDB != null)
        {
            foreach (var s in _inv.Inventory.slots)
            {
                if (s != null && s.count > 0 && !string.IsNullOrEmpty(s.id))
                {
                    var e = plantDB.GetByPlantItemId(s.id);
                    if (e != null)
                    {
                        // ˳�������Ϊ���������ֱ��
                        try { _active?.SetActive(s.id, true); } catch { }
                        return s.id;
                    }
                }
            }
        }
        return null;
    }

    bool StillHasItem(string id)
    {
        if (string.IsNullOrEmpty(id) || _inv?.Inventory?.slots == null) return false;
        foreach (var s in _inv.Inventory.slots)
            if (s != null && s.count > 0 && s.id == id) return true;
        return false;
    }

    bool Raycast(out RaycastHit hit)
    {
        Ray ray;
        if (useCameraRay && Camera.main)
            ray = Camera.main.ScreenPointToRay(new Vector3(Screen.width * 0.5f, Screen.height * 0.5f));
        else
            ray = new Ray(transform.position + Vector3.up * 1.2f, transform.forward);

        return Physics.Raycast(ray, out hit, maxDistance, raycastLayers, QueryTriggerInteraction.Ignore);
    }
}
