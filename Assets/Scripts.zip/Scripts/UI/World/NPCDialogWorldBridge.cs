// Assets/Scripts/UI/World/NPCDialogWorldBridge.cs
using UnityEngine;
using TMPro;
using System.Reflection;
using UnityEngine.UI;

/// <summary>
/// 将 NPCDialogUI 的“台词文本”重定向到 3D 气泡中显示：
/// - 不改原 UI 按钮/逻辑；
/// - 面板打开时把 lineText 设为透明，仅把文字渲染到世界空间气泡；
/// - 加：玩家远离自动隐藏；
/// - 加：开放商店台词接口（不依赖 lineText，供商店逻辑主动播放）。
/// </summary>
[DisallowMultipleComponent]
public class NPCDialogWorldBridge : MonoBehaviour
{
    [Header("References")]
    public NPCDialogUI ui;                       // 原对话 UI
    [Tooltip("优先在 NPC 子物体里寻找的锚点名；找不到则再用 Collider 顶部。")]
    public string anchorChildName = "BubbleAnchor";

    [Header("Bubble")]
    public SpeechBubble3D bubblePrefab;          // 可空：空则运行时自动构建一个简易气泡
    public Vector3 bubbleOffset = new Vector3(0f, 1.8f, 0f);
    [Range(160f, 800f)]
    public float bubbleMaxWidth = 320f;

    [Header("Behaviour")]
    public bool enableWorldBubble = true;

    [Header("Auto Hide By Distance")]
    [Tooltip("是否根据与玩家的距离，自动隐藏气泡/对话。")]
    public bool enableAutoHideByDistance = true;
    [Tooltip("水平距离超过此值时隐藏（米）。")]
    public float hideDistance = 4.0f;
    [Tooltip("寻找玩家用的 Tag。若留空，将使用 Camera.main.transform 作为距离参考。")]
    public string playerTag = "Player";
    [Tooltip("当距离超出阈值时，是否顺带把 NPCDialogUI 面板也关掉。")]
    public bool alsoCloseUIDialog = true;

    // 运行时
    private SpeechBubble3D _bubble;
    private Transform _anchor;
    private object _currentNPC;                  // 通过反射读取 ui.CurrentNPC
    private string _lastLineText = "";
    private TextMeshProUGUI _lineTextTMP;
    private Text _lineTextUGUI;
    private PropertyInfo _propCurrentNPC;
    private FieldInfo _fieldCurrentNPC;
    private Transform _player;                   // 距离检测

    // —— 商店/自定义台词（独立于 lineText）——
    private bool _standaloneMode = false;        // true 表示当前台词来源于 ShowStandalone/PlayOneLine，而不是 UI lineText
    private Transform _standaloneNPC;            // 商店/自定义台词使用的 NPC/锚点根
    private string _standaloneLine = "";

    void Awake()
    {
        if (!ui) ui = GetComponent<NPCDialogUI>();
        CacheLineText();

        _propCurrentNPC = typeof(NPCDialogUI).GetProperty("CurrentNPC", BindingFlags.Public | BindingFlags.Instance);
        _fieldCurrentNPC = typeof(NPCDialogUI).GetField("CurrentNPC", BindingFlags.Public | BindingFlags.Instance);

        // 找玩家
        if (!string.IsNullOrEmpty(playerTag))
        {
            var go = GameObject.FindGameObjectWithTag(playerTag);
            if (go) _player = go.transform;
        }
        if (!_player && Camera.main) _player = Camera.main.transform; // 兜底
    }

    void CacheLineText()
    {
        // 兼容 TMP 和 UGUI 两种文本
        var t = typeof(NPCDialogUI);
        var f1 = t.GetField("lineText", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
        if (f1 != null)
        {
            _lineTextTMP = f1.GetValue(ui) as TextMeshProUGUI;
            if (!_lineTextTMP)
            {
                _lineTextUGUI = f1.GetValue(ui) as Text;
            }
        }
    }

    void Update()
    {
        if (!enableWorldBubble) return;

        // 是否打开 UI 面板
        bool isOpen = false;
        GameObject rootGO = null;
        {
            var fRoot = typeof(NPCDialogUI).GetField("root", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (fRoot != null)
            {
                rootGO = fRoot.GetValue(ui) as GameObject;
                isOpen = rootGO && rootGO.activeInHierarchy;
            }
        }

        // —— 距离隐藏（无论是 UI 台词还是独立台词）——
        if (enableAutoHideByDistance && _player && (_anchor || _standaloneNPC))
        {
            var refTr = _anchor ? _anchor : _standaloneNPC;
            if (refTr)
            {
                Vector3 a = _player.position; a.y = 0;
                Vector3 b = refTr.position; b.y = 0;
                float planar = Vector3.Distance(a, b);
                if (planar > hideDistance)
                {
                    HideBubble();
                    if (alsoCloseUIDialog && rootGO) rootGO.SetActive(false); // 可选：把面板也关掉
                    _standaloneMode = false; // 退出独立台词状态
                    return;
                }
            }
        }

        if (_standaloneMode)
        {
            // —— 独立台词：由 ShowStandalone/PlayOneLine 提供 —— 
            if (_bubble == null || _anchor == null)
            {
                _anchor = ResolveAnchor(_standaloneNPC);
                EnsureBubble();
                _bubble.transform.SetParent(null, worldPositionStays: true);
                _bubble.Init(_anchor, Camera.main, bubbleMaxWidth, bubbleOffset);
                _bubble.SetText(_standaloneLine);
                MakeUILineTransparent(); // 按原逻辑透明掉 UI 文字，保留按钮
            }
            else
            {
                // 独立台词期间若更换文本，可调用 SetStandaloneLine
            }
            return; // 独立模式下不再读取 UI 的 lineText
        }

        // —— 正常模式：读取 UI 的 lineText 同步到气泡 —— 
        _currentNPC = GetCurrentNPCObj();
        if (!isOpen || _currentNPC == null)
        {
            HideBubble();
            return;
        }

        string line = ReadCurrentLineText(); if (line == null) line = "";

        if (_bubble == null || _anchor == null)
        {
            _anchor = ResolveAnchor(GetNPCTransform(_currentNPC));
            EnsureBubble();
            _bubble.transform.SetParent(null, worldPositionStays: true);
            _bubble.Init(_anchor, Camera.main, bubbleMaxWidth, bubbleOffset);
            _bubble.SetText(line);
            MakeUILineTransparent();
        }

        if (_bubble != null && _lastLineText != line)
        {
            _bubble.SetText(line);
            _lastLineText = line;
        }
    }

    // ======== 对外 API：商店/自定义台词 ========

    /// <summary>
    /// 在指定 NPC（或其子物体）头顶，播放一条独立台词（不依赖 UI 面板）。
    /// 常用于：打开商店时“欢迎光临～”，或其他系统提示。
    /// </summary>
    public void ShowStandalone(Transform npcRootOrAnchor, string line)
    {
        if (!npcRootOrAnchor) return;
        _standaloneMode = true;
        _standaloneNPC = npcRootOrAnchor;
        _standaloneLine = line ?? "";
        _lastLineText = ""; // 与 UI 台词无关
        // 立即刷新一次
        _anchor = ResolveAnchor(_standaloneNPC);
        EnsureBubble();
        _bubble.transform.SetParent(null, worldPositionStays: true);
        _bubble.Init(_anchor, Camera.main, bubbleMaxWidth, bubbleOffset);
        _bubble.SetText(_standaloneLine);
        MakeUILineTransparent();
    }

    /// <summary>更新独立台词的内容（在商店打开期间可随时更换）。</summary>
    public void SetStandaloneLine(string line)
    {
        _standaloneLine = line ?? "";
        if (_standaloneMode && _bubble) _bubble.SetText(_standaloneLine);
    }

    /// <summary>结束独立台词（例如商店关闭时）。</summary>
    public void EndStandalone()
    {
        _standaloneMode = false;
        HideBubble();
    }

    // ======== 内部工具 ========

    string ReadCurrentLineText()
    {
        if (_lineTextTMP) return _lineTextTMP.text;
        if (_lineTextUGUI) return _lineTextUGUI.text;
        return "";
    }

    object GetCurrentNPCObj()
    {
        if (_propCurrentNPC != null)
            return _propCurrentNPC.GetValue(ui);
        if (_fieldCurrentNPC != null)
            return _fieldCurrentNPC.GetValue(ui);
        return null;
    }

    Transform GetNPCTransform(object npcObj)
    {
        if (npcObj == null) return null;
        var tNpc = npcObj.GetType();
        var pTr = tNpc.GetProperty("transform", BindingFlags.Public | BindingFlags.Instance);
        return pTr != null ? pTr.GetValue(npcObj) as Transform : null;
    }

    Transform ResolveAnchor(Transform npcTransform)
    {
        if (!npcTransform) return null;

        // 1) 优先子物体锚点
        if (!string.IsNullOrEmpty(anchorChildName))
        {
            var child = npcTransform.Find(anchorChildName);
            if (child) return child;
        }

        // 2) Collider 顶部
        Collider npcCollider = npcTransform.GetComponent<Collider>();
        if (!npcCollider)
        {
            // 在子物体里找一个“像身体”的碰撞体，尽量避开巨大触发器
            var all = npcTransform.GetComponentsInChildren<Collider>();
            float best = float.PositiveInfinity;
            foreach (var c in all)
            {
                var sz = c.bounds.size;
                float height = sz.y;
                float volume = sz.x * sz.y * sz.z;
                float score = height * 2f + volume; // 越矮越小越好
                if (score < best && height > 0.3f && volume < 50f)
                {
                    best = score;
                    npcCollider = c;
                }
            }
        }
        if (npcCollider)
        {
            var go = new GameObject("BubbleAnchor(auto)");
            go.transform.SetParent(npcCollider.transform, false);
            var b = npcCollider.bounds;
            go.transform.position = new Vector3(b.center.x, b.max.y, b.center.z);
            return go.transform;
        }

        // 3) 兜底
        return npcTransform;
    }

    void EnsureBubble()
    {
        if (_bubble == null)
        {
            if (bubblePrefab) _bubble = Instantiate(bubblePrefab);
            else _bubble = new GameObject("SpeechBubble3D").AddComponent<SpeechBubble3D>();
        }
    }

    void MakeUILineTransparent()
    {
        if (_lineTextTMP)
        {
            var c = _lineTextTMP.color; c.a = 0f; _lineTextTMP.color = c;
        }
        if (_lineTextUGUI)
        {
            var c2 = _lineTextUGUI.color; c2.a = 0f; _lineTextUGUI.color = c2;
        }
    }

    void RestoreUILineVisibility()
    {
        if (_lineTextTMP) { var c = _lineTextTMP.color; c.a = 1f; _lineTextTMP.color = c; }
        if (_lineTextUGUI) { var c2 = _lineTextUGUI.color; c2.a = 1f; _lineTextUGUI.color = c2; }
    }

    void HideBubble()
    {
        if (_bubble) _bubble.Hide();
        RestoreUILineVisibility();
        _lastLineText = "";
        _anchor = null;
    }
}
