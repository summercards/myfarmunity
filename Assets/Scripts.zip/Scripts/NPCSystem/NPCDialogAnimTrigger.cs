using UnityEngine;

namespace FarmGame.NPCSystem
{
    /// <summary>
    /// ���� NPCDialogUI�����Ի������ҵ�ǰ NPC = �Լ�ʱ������ NPCVisualController �� BeginTalk/EndTalk��
    /// ������ʽ���Զ��ڳ����� Find һ�� NPCDialogUI��
    /// </summary>
    [DisallowMultipleComponent]
    public class NPCDialogAnimTrigger : MonoBehaviour
    {
        public NPCDefinition definition;
        public MonoBehaviour npcInteractable;     // ��� NPCInteractable���Զ��ң�
        public Component dialogUI;                // ������� NPCDialogUI���Զ��ң�
        public NPCVisualController visual;        // ͬ�ڵ��ϵ��Ӿ����������Զ��ң�

        private bool _lastTalking = false;

        private void Reset() => TryAutoFill();

        private void Awake()
        {
            TryAutoFill();
        }

        private void Update()
        {
            if (definition == null) return;
            if (npcInteractable == null || dialogUI == null || visual == null) return;

            // ��ȡ UI ״̬
            var uiType = dialogUI.GetType();
            var isOpenProp = uiType.GetProperty("IsOpen");
            var currentNpcProp = uiType.GetProperty("CurrentNPC");

            if (isOpenProp == null || currentNpcProp == null) return;

            bool isOpen = false;
            object currentNpc = null;
            try
            {
                isOpen = (bool)isOpenProp.GetValue(dialogUI);
                currentNpc = currentNpcProp.GetValue(dialogUI);
            }
            catch { return; }

            bool talkingNow = isOpen && ReferenceEquals(currentNpc, npcInteractable);

            if (talkingNow != _lastTalking)
            {
                _lastTalking = talkingNow;
                if (talkingNow) visual.BeginTalk();
                else visual.EndTalk();
            }
        }

        public void TryAutoFill()
        {
            if (visual == null) visual = GetComponent<NPCVisualController>();
            if (definition == null && visual != null) definition = visual.definition;

            if (npcInteractable == null)
            {
                npcInteractable = GetComponent<MonoBehaviour>();
                // �Ұ�����NPCInteractable���Ľű�
                foreach (var mb in GetComponents<MonoBehaviour>())
                {
                    if (mb != null && mb.GetType().Name.ToLower().Contains("npcinteractable"))
                    {
                        npcInteractable = mb; break;
                    }
                }
            }

            if (dialogUI == null)
            {
                // �ڳ�������һ���� NPCDialogUI �����
                foreach (var c in FindObjectsOfType<MonoBehaviour>(true))
                {
                    if (c != null && c.GetType().Name.ToLower().Contains("npcdialogui"))
                    {
                        dialogUI = c; break;
                    }
                }
            }
        }
    }
}
